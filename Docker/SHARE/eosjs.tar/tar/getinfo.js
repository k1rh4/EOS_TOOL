const Eos = require('eosjs')

const config = {
    httpEndpoint:'https://jungle.eoscanada.com'
};

Eos(config).getInfo((error,info)=>{
    if(error){
        console.error(error);
    }
    console.log(info);
});

