const Eos = require('eosjs')

const config = {
    httpEndpoint:'https://jungle.eoscanada.com',
    chainId:'e70aaab8997e1dfce58fbfac80cbbb8fecec7b99cf982a9444273cbc64c41473',
    keyProvider:['5JDoY1wFPHQmHurtQcGah3J13wrygRytGDodUQBrotmdwoFHmsF']
};

Eos(config).transfer('kirhatester3','kirhatester2','10.0000 EOS','transfer token', (error,result)=>{
    if(error){
        console.error(error);
    }
    console.log(result);
});

